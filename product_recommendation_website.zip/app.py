from flask import Flask, render_template, request
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import MinMaxScaler

app = Flask(__name__)

df = pd.read_csv("data.csv")

user_item_matrix = df.pivot_table(index='UserID', columns='ProductID', values='Rating').fillna(0)

scaler = MinMaxScaler()
normalized_matrix = scaler.fit_transform(user_item_matrix)

knn = NearestNeighbors(metric='cosine', algorithm='brute')
knn.fit(normalized_matrix)

def recommend_products(user_id, k=2):
    user_index = user_item_matrix.index.get_loc(user_id)
    distances, indices = knn.kneighbors([normalized_matrix[user_index]], n_neighbors=k+1)
    similar_users = user_item_matrix.index[indices.flatten()[1:]]
    recommendations = pd.Series(dtype=float)
    for user in similar_users:
        recommendations = recommendations.add(user_item_matrix.loc[user], fill_value=0)
    already_rated = user_item_matrix.loc[user_id]
    recommendations = recommendations[already_rated == 0]
    return recommendations.sort_values(ascending=False)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommend', methods=['POST'])
def recommend():
    user_id = int(request.form['user_id'])
    products = recommend_products(user_id)
    return render_template('recommend.html', products=products)

if __name__ == '__main__':
    app.run(debug=True)
